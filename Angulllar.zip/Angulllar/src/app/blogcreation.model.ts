export class Blogcreation {
    constructor(public id:number, 
        public pteading: string, 
        public ptext: string, 
        public author: string) {}
}
