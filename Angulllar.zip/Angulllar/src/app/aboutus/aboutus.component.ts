import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Blogcreation } from '../blogcreation.model';
import { BlogcreationService } from '../blogcreation.service';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {

  allBlogs?:Array<Blogcreation>; // This will get all data from json and store in Array
  changeMessage : string = ""
  constructor( public pser:BlogcreationService) { }// DI for service class inside cvonstructor

  ngOnInit(): void {
    this.pser.retrieveBlogPostDetails().subscribe(result=>this.allBlogs=result);
  }

  deleteRecord(id:any){
    console.log("Delete " + id)
    this.pser.deleteBlogRecord(id).subscribe(result=>{
      this.pser.retrieveBlogPostDetails().subscribe(result=>this.allBlogs=result);
      this.changeMessage = "Blog Deleted Successfully"
    })
  }


}
