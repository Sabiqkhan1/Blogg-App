import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Blogcreation } from '../blogcreation.model';
import { BlogcreationService } from '../blogcreation.service';

@Component({
  selector: 'app-blogcreation',
  templateUrl: './blogcreation.component.html',
  styleUrls: ['./blogcreation.component.css']
})
export class BlogcreationComponent implements OnInit {
  productRef = new FormGroup({ // Form group to enter blog post - links to html page
    id: new FormControl(),
    pteading: new FormControl(),
    ptext: new FormControl(),
    author: new FormControl()

  })
  resultMessage: string="";
  changeMessage : string = ""
  allBlogs?:Array<Blogcreation>; // This will get al;l data from json and store in Array
  buttonValue:string="Create Blog"

  constructor( public pser:BlogcreationService) { }// DI for service class inside cvonstructor

  ngOnInit(): void {
    this.pser.retrieveBlogPostDetails().subscribe(result=>this.allBlogs=result);
  }

  storeBlog(){
    if(this.buttonValue=="Create Blog"){
    let blogPost = this.productRef.value;
    this.pser.storeBlogPostDetails(blogPost).subscribe(result => {
      this.resultMessage="Great! Blog Post Stored Successfully!"
      this.pser.retrieveBlogPostDetails().subscribe(result=>this.allBlogs=result);
    },error => {
      this.resultMessage="Oh no! Blog Post Didn't Store :(";
    })
  }else {
    let blogPost = this.productRef.value;
    this.pser.updateBlogDetail(blogPost).subscribe(result => {
      this.resultMessage="Great! Blog Post UPDATED Successfully!"
      this.pser.retrieveBlogPostDetails().subscribe(result=>this.allBlogs=result);
      this.buttonValue="Create Blog"
    },error => {
      this.resultMessage="Oh no! Blog Post Didn't UPDATE :(";
    })
  };
  }

  
  deleteRecord(id:any){
    console.log("Delete " + id)
    this.pser.deleteBlogRecord(id).subscribe(result=>{
      this.pser.retrieveBlogPostDetails().subscribe(result=>this.allBlogs=result);
      this.changeMessage = "Blog Deleted Successfully"
    })
  }

  updateRecord(blog:any){
    this.productRef.setValue(blog);
    this.buttonValue="Update Blog";
  }

}
