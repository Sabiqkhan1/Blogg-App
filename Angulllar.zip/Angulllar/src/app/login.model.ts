export class Login {
    constructor(public user:string,
        public pass:string) {}
}
