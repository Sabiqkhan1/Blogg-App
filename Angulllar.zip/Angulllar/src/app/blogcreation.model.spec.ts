import { Blogcreation } from './blogcreation.model';

describe('Blogcreation', () => {
  it('should create an instance', () => {
    expect(new Blogcreation()).toBeTruthy();
  });
});
