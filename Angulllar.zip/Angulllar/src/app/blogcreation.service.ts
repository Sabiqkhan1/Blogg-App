import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Blogcreation } from './blogcreation.model';

@Injectable({
  providedIn: 'root'
})
export class BlogcreationService {

  //Creating DI for HTTP client
  constructor(public http:HttpClient) { } 

  //!st parameter Url second Parameter Json object
  //Store new blog post entry from form filled out
  storeBlogPostDetails(blogPost:any):Observable<Blogcreation>{
    //this.http.post("http://localhost:8000/blog",blogPost).subscribe(result=>console.log(result),error=>console.log(error))
    return this.http.post<Blogcreation>("http://localhost:8000/blog",blogPost);
    
  }

  //Retrieve Data from Json file to display (GET method)

  retrieveBlogPostDetails():Observable<Blogcreation[]>{
    return this.http.get<Blogcreation[]>("http://localhost:8000/blog");
  }

  //Delete Blog record

  deleteBlogRecord(id:any):Observable<Blogcreation>{
    return this.http.delete<Blogcreation>("http://localhost:8000/blog/"+id)
  }
// update blog record
  updateBlogDetail(product:any):Observable<Blogcreation>{
    return this.http.put<Blogcreation>("http://localhost:8000/blog/"+ product.id, product);
  }


}
