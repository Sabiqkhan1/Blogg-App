import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {
  contactRef = new FormGroup({
    name:new FormControl(),
    query:new FormControl(),
    email: new FormControl()

  });


  constructor(public router:Router) { }

  ngOnInit(): void {
  }

  returnHome() {
    this.router.navigate(["home"]);
  }

}
